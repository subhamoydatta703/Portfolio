import { Theme } from './settings/types';
import { CraftDirectionRevisedTypography } from './components/generated/CraftDirectionRevisedTypography';

let theme: Theme = 'light';

function App() {
  function setTheme(theme: Theme) {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  setTheme(theme);

  return (
    <>
      <CraftDirectionRevisedTypography />
    </>
  ); // %EXPORT_STATEMENT%
}

export default App;
