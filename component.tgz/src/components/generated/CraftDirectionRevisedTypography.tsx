import { GitHubActivity } from './GitHubActivity';
import { skillCategories } from './skills-data';
const rexaScreenshot = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464355913646637056/d2005b91dbec0ec51587357898daf69a5be1b62746fa9aabd56c4c86b3b0df8a.png";
const docsenseScreenshot = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464355913646637056/371af2fd823874e3fb0c6921a97365c4d8fa9976824f8ed677d8b1a0d9e60873.png";
const marinScreenshot = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464355913646637056/33d9a7668c3bb6d3df622a3e2a2039515fafd62b43435acea40bb3e5c004fbcd.png";
const somoyScreenshot = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464355913646637056/a6010b0aa134cf35be1228e029d66aa66ca06beebeebd40001bfc4710e57c6f0.png";
const resumarkScreenshot = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464355913646637056/0a84889677e2ce5a51fad49964b831b7741e6e8eb2138052e88f97390ea54398.png";
const shelflifeScreenshot = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464355913646637056/a9033c9137a65fea5c6b52912aabba6b4ec1a3ac0129140fa1ed1893db237a10.png";
const profileImage = "https://storage.googleapis.com/storage.magicpath.ai/component-assets/464279670272200704/464344766201602048/a059387d874f969be8c26a1a002d117f6258a83c525823f648f5f1727e543bb9.png";
import { useEffect, useRef, useState } from 'react';
import './portfolio.css';
import './layout-refinements.css';
const projects = [{
  name: 'REXA',
  kind: 'CLI coding agent',
  version: 'v2.0.0',
  description: 'A coding agent with Plan and Act modes, Docker isolation and guardrails for code execution.',
  tags: 'TypeScript · Bun · Docker',
  repo: 'REXA',
  url: 'https://npmjs.com/package/rexa-agent',
  action: 'Package'
}, {
  name: 'somoy',
  kind: 'TypeScript agent SDK',
  description: 'A provider-agnostic SDK for building agents with typed tools, handoffs and explicit failure states.',
  tags: 'TypeScript · Zod · Gemini · OpenAI',
  repo: 'Agent-SDK',
  url: 'https://npmjs.com/package/@subhamoy/somoy',
  action: 'Package'
}, {
  name: 'DocSense',
  kind: 'Document intelligence',
  description: 'Ask questions across PDFs, websites, YouTube videos and text. Built with semantic search and background processing.',
  tags: 'pgvector · Redis · BullMQ · AWS S3',
  repo: 'DocSense',
  url: 'https://docsense-app.vercel.app',
  action: 'Live demo'
}];
const additionalProjects = [{
  name: 'Marin',
  kind: 'Voice AI companion',
  version: '',
  description: 'A full-duplex voice companion with local Whisper transcription, interruption handling and emotion-aware speech.',
  tags: 'Python · Whisper · Gemini · CUDA',
  repo: 'Marin',
  url: '',
  action: ''
}, {
  name: 'Resumark',
  kind: 'AI resume analysis',
  version: '',
  description: 'Resume analysis with Gemini, asynchronous processing, authentication and cloud storage.',
  tags: 'Express · PostgreSQL · BullMQ · AWS S3',
  repo: 'Resumark',
  url: 'https://resumark-webapp.vercel.app/',
  action: 'Live demo'
}, {
  name: 'ShelfLife',
  kind: 'Household inventory',
  version: '',
  description: 'Pantry inventory and expiry tracking, with authenticated REST APIs and MongoDB storage.',
  tags: 'Node.js · Express · MongoDB · JWT',
  repo: 'Shelf-Life',
  url: 'https://shelflifwebapp.vercel.app/',
  action: 'Live demo'
}];
const featuredProjects = [projects[0], projects[2], additionalProjects[0]];
const moreProjects = [projects[1], additionalProjects[1], additionalProjects[2]];
const projectScreenshots: Record<string, {
  src: string;
  alt: string;
  theme: string;
}> = {
  REXA: {
    src: rexaScreenshot,
    alt: 'REXA v2.0.0 terminal showing its agent harness and Plan and Act modes',
    theme: 'rexa'
  },
  DocSense: {
    src: docsenseScreenshot,
    alt: 'DocSense document intelligence homepage with supported document sources',
    theme: 'docsense'
  },
  Marin: {
    src: marinScreenshot,
    alt: 'Marin voice companion showing hands-free listening and live transcript',
    theme: 'marin'
  },
  somoy: {
    src: somoyScreenshot,
    alt: 'The @subhamoy/somoy package published on npm',
    theme: 'somoy'
  },
  Resumark: {
    src: resumarkScreenshot,
    alt: 'Resumark resume analysis homepage and document audit preview',
    theme: 'resumark'
  },
  ShelfLife: {
    src: shelflifeScreenshot,
    alt: 'ShelfLife household inventory sign-in screen',
    theme: 'shelflife'
  }
};
type PortfolioProject = typeof featuredProjects[number];
function ProjectTile({
  project: p,
  index,
  extra = false
}: {
  project: PortfolioProject;
  index: number;
  extra?: boolean;
}) {
  const screenshot = projectScreenshots[p.name];
  return <article className={extra ? 'project extra-project' : 'project'} data-reveal={extra ? undefined : true} style={extra ? {
    transitionDelay: index * 70 + 'ms'
  } : undefined}>
    <div className={"project-image screenshot-frame screenshot-" + screenshot.theme}><img src={screenshot.src} alt={screenshot.alt} loading="lazy" decoding="async" /></div>
    <div className="project-title"><h3>{p.name}</h3>{p.version && <span className="version">{p.version}</span>}<span className="kind">{p.kind}</span></div>
    <p>{p.description}</p><small className="tags">{p.tags}</small>
    <div className="project-links"><a href={'https://github.com/subhamoydatta703/' + p.repo}>Source ↗</a>{p.url && <a href={p.url}>{p.action} ↗</a>}</div>
  </article>;
}
const resume = 'https://drive.google.com/file/d/19lfm2kUQvaWSybn_xV-_4e-STtAKrv3s/view?usp=sharing';
export const CraftDirectionRevisedTypography = () => {
  const root = useRef<HTMLDivElement>(null);
  const [showMore, setShowMore] = useState(false);
  const [activeSkillCategory, setActiveSkillCategory] = useState(0);
  useEffect(() => {
    const elements = root.current?.querySelectorAll<HTMLElement>('[data-reveal]');
    let frame = 0;
    const update = () => {
      frame = 0;
      const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
      elements?.forEach(el => {
        const progress = reduced ? 1 : Math.max(0, Math.min(1, (innerHeight - el.getBoundingClientRect().top) / (innerHeight * .28)));
        el.style.opacity = String(.18 + .82 * progress);
        el.style.transform = `translateY(${(1 - progress) * 28}px)`;
      });
    };
    const scroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', scroll, {
      passive: true
    });
    window.addEventListener('resize', scroll);
    const observer = new ResizeObserver(scroll);
    if (root.current) observer.observe(root.current);
    return () => {
      window.removeEventListener('scroll', scroll);
      window.removeEventListener('resize', scroll);
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, []);
  return <div className="folio" ref={root}>
 <header className="nav wrap"><a className="identity" href="#home">Subhamoy Datta</a><nav aria-label="Main navigation"><a href="#work">Work</a><a href="#about">About</a><a href="#contact">Contact</a></nav><a className="nav-contact" href="mailto:subhamoydatta703@gmail.com">Get in touch ↗</a></header>
 <main id="home">
 <section className="hero wrap"><div className="hero-copy"><p className="availability"><span />Open to internships</p><h1>Backend Engineer.<br />GenAI &amp;<br />Agentic Systems.</h1><p className="intro">Building and publishing agentic systems&mdash;from agent harnesses to orchestration&mdash;and developing and deploying RAG pipelines and LLM-powered backend systems.</p><div className="actions"><a className="button" href="#work">View my work <span>↘</span></a><a className="textlink" href="https://github.com/subhamoydatta703">GitHub ↗</a><a className="textlink" href={resume} target="_blank" rel="noreferrer">Resume ↗</a></div></div><div className="hero-portrait"><img src={profileImage} alt="Subhamoy Datta profile avatar" width="736" height="736" /></div></section>
 <section id="work" className="work wrap"><div className="section-head" data-reveal><h2>Selected projects<span> / 01</span></h2><p>Agentic systems, RAG pipelines<br />and AI-powered backends.</p></div>
    <div className="project-grid featured-grid">{featuredProjects.map((project, index) => <ProjectTile key={project.name} project={project} index={index} />)}</div>
    <div className="more-projects-control"><button type="button" className="more-projects-button" aria-expanded={showMore} aria-controls="additional-projects" onClick={() => setShowMore(value => !value)}>{showMore ? 'Show fewer projects' : 'More projects'}<span aria-hidden="true" className={showMore ? 'expand-icon is-open' : 'expand-icon'}>+</span></button></div>
    <div id="additional-projects" className={showMore ? 'projects-expansion is-open' : 'projects-expansion'} inert={!showMore} aria-hidden={!showMore}><div className="expansion-clip"><div className="project-grid additional-grid">{moreProjects.map((project, index) => <ProjectTile key={project.name} project={project} index={index} extra />)}</div></div></div>
  </section>
 <section id="skills" className="skills wrap" aria-labelledby="skills-heading" data-reveal>
  <div className="section-head"><h2 id="skills-heading">Skills &amp; tools<span> / 02</span></h2><p>Technologies and engineering practices<br />I use across my projects.</p></div>
  <div className="skills-browser">
    <div className="skill-categories" role="group" aria-label="Skill categories">{skillCategories.map((category, index) => <button key={category.label} type="button" className={activeSkillCategory === index ? 'skill-category is-active' : 'skill-category'} aria-pressed={activeSkillCategory === index} aria-controls="skill-details" onClick={() => setActiveSkillCategory(index)}><span>{category.label}</span><span className="skill-category-count">{String(category.skills.length).padStart(2, '0')}</span></button>)}</div>
    <div id="skill-details" className="skill-details" aria-labelledby="active-skill-heading"><div className="skill-detail-heading"><h3 id="active-skill-heading">{skillCategories[activeSkillCategory].label}</h3><span>{skillCategories[activeSkillCategory].skills.length} entries</span></div><ul className="skill-items" key={activeSkillCategory}>{skillCategories[activeSkillCategory].skills.map(skill => <li key={skill}>{skill}</li>)}</ul></div>
  </div>
</section>
 <GitHubActivity />
 <section id="about" className="about wrap" data-reveal><div className="section-head"><h2>About me<span> / 04</span></h2></div><div className="about-grid"><div><p className="about-lead">I'm Subhamoy, a Computer Science student focused on backend engineering, GenAI and agentic systems.</p><p className="about-education">B.Tech in Computer Science &amp; Engineering (AI &amp; ML)<br />Brainware University</p></div><div className="about-story"><p>My projects range from agent harnesses and orchestration to RAG pipelines and LLM-powered backend systems. I've published REXA and somoy on npm, and built and deployed applications including DocSense and Resumark.</p><p>I'm looking for an internship where I can contribute to backend and AI systems, work with an engineering team, and deepen the experience I've gained through these projects.</p><div className="recognition"><span className="eyebrow">RECOGNITION</span><h3>1st place &mdash; Frontend Odyssey</h3><p>IIT Patna &middot; Hosted on Unstop</p></div></div></div></section>
 <footer id="contact" className="footer wrap" data-reveal>
  <div className="contact-grid">
    <div className="contact-intro"><span className="eyebrow">CONTACT</span><h2>Let’s talk.</h2><p>Have an internship opportunity or a project in mind? I’d be glad to hear about it.</p><div className="contact-availability"><span aria-hidden="true" />Open to internships</div></div>
    <div className="contact-options"><span className="eyebrow">GET IN TOUCH</span><div className="contact-primary"><a className="button" href="mailto:subhamoydatta703@gmail.com">Email <span aria-hidden="true">↗</span></a></div><div className="contact-elsewhere"><span className="eyebrow">FIND ME ELSEWHERE</span><div><a href="https://www.linkedin.com/in/subhamoy-datta" target="_blank" rel="noreferrer">LinkedIn ↗</a><a href="https://github.com/subhamoydatta703" target="_blank" rel="noreferrer">GitHub ↗</a><a href="https://x.com/codebysubhamoy" target="_blank" rel="noreferrer">X ↗</a><a href="https://leetcode.com/u/26W5VCTCTA" target="_blank" rel="noreferrer">LeetCode ↗</a></div></div></div>
  </div>
  <div className="footer-bottom"><span>Subhamoy Datta</span><div><a href={resume} target="_blank" rel="noreferrer">Resume ↗</a><a href="#home">Back to top ↑</a></div></div>
</footer>
 </main></div>;
};