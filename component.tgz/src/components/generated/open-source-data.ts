export const openSourcePullRequests = [
  {
    "repo": "keshav7x/RAGX",
    "number": 6,
    "title": "Feature/output guardrail",
    "url": "https://github.com/keshav7x/RAGX/pull/6",
    "status": "Merged",
    "mergedAt": "2026-10-02T10:06:20Z"
  },
  {
    "repo": "soumojitbagchi/BonGazon",
    "number": 1,
    "title": "Fix the backend and the frontend and update the codebase",
    "url": "https://github.com/soumojitbagchi/BonGazon/pull/1",
    "status": "Merged",
    "mergedAt": "2026-08-14T18:11:08Z"
  },
  {
    "repo": "agentguard-ai/tealtiger",
    "number": 581,
    "title": "feat(mcp): add SSE and Streamable HTTP CLI transports",
    "url": "https://github.com/agentguard-ai/tealtiger/pull/581",
    "status": "Open",
    "mergedAt": null
  },
  {
    "repo": "trailhq/Trail-Code",
    "number": 517,
    "title": "fix: remove misleading tokens saved claim",
    "url": "https://github.com/trailhq/Trail-Code/pull/517",
    "status": "Open",
    "mergedAt": null
  }
];
